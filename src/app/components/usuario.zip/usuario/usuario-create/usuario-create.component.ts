import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usuario-create',
  templateUrl: './usuario-create.component.html',
  styleUrls: ['./usuario-create.component.css']
})
export class UsuarioCreateComponent implements OnInit {
Usuario: any;
createUsuario() {
throw new Error('Method not implemented.');
}
cancel() {
throw new Error('Method not implemented.');
}
createProduct() {
throw new Error('Method not implemented.');
}
produto: any;
navigateToUsuarioCreate() {
throw new Error('Method not implemented.');
}

  constructor() { }

  ngOnInit(): void {
  }

}
