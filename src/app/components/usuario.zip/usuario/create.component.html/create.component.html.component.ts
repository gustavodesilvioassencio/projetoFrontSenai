import { Component } from '@angular/core';

@Component({
  selector: 'app-create.component.html',
  templateUrl: './create.component.html.component.html',
  styleUrls: ['./create.component.html.component.css']
})
export class CreateComponentHtmlComponent {

}
